module.exports = {
  // Token tài khoản Discord (Selfbot)
  DISCORD_TOKEN: "",
  // Token Bot Discord
  BOT_TOKEN: "MTUyMjI5NzkxOTk0MjY5MjkxNA.GxQIhR.k3Vw3agov2hm0MRRbdalP0Wvmk3RDJR6EckESE",
  // Danh sách các ID Discord Admin
  ADMIN_IDS: ["1122110156847726632"]
};
